﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WriterLibrary
{
    public static class ListBuilder
    {
        public static List<Person> people = new List<Person>();

       /** public static void BuildList(string firstName, string middleName, string lastName, int age)
        {
            people.Add(new Person(firstName, middleName, lastName, age));
        }*/
    }
}
