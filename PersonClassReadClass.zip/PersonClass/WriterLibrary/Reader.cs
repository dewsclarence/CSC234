﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WriterLibrary
{
    public static class Reader
    {
        public static string ReadFile()
        {
            StreamReader inputFile;

            try
            {
                inputFile = File.OpenText("UserInformation.txt");

                while (!inputFile.EndOfStream)
                {
                    string[] tokens = inputFile.ReadLine().Split(',');

                    ListBuilder.people.Add(new Person(tokens[0], tokens[1], tokens[2], int.Parse(tokens[3])));
                }
                inputFile.Close();
                return "Loaded";
            }
            catch(Exception ex)
            {
                string message = ex.Message;
                return message;
            }
        }
    }
}
