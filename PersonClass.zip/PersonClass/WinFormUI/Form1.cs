﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WriterLibrary;
/**
* 9/21/2021
* CSC 253
* Clarence G Dews
* For this program you can start from scratch or you may use one of your programs from CSC 153 (if you have one).
* Create a program that has a "Person" class. This class's information is filled in by the user. This will take planning and thinking through, do not rush into programming. 
* Then the program should read and save all this information from the class (not as it is put in) and save it to a file named "UserInformation".
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void createFileButton_Click(object sender, EventArgs e)
        {
            string firstName = firstNameTextBox.Text;
            string middleName = middleNameTextBox.Text;
            string lastName = lastNameTextBox.Text;
            int age = int.Parse(ageTextBox.Text);
            ListBuilder.BuildList(firstName, middleName, lastName, age);
            MessageBox.Show(Writer.WriteToFile());
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            firstNameTextBox.Text = "";
            middleNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            ageTextBox.Text = " ";

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
