﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WriterLibrary
{
    public class Person
    {
        private string _firstName;
        private string _middleName;
        private string _lastName;
        private int _age;

        public Person()
        {
            FirstName = "";
            MiddleName = "";
            LastName = "";
            Age = 0;
        }
        public Person(string firstName, string middleName, string lastName, int age)
        {
            FirstName = firstName;
            MiddleName = middleName;
            LastName = lastName;
            Age = age;
        }
        public string FirstName
        {
            get
            {
                return _firstName;
            }

            set
            {
                _firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return _lastName;
            }

            set
            {
                _lastName = value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }

            set
            {
                _age = value;
            }
        }
        public string MiddleName 
        {
            get 
            {
                return _middleName;
            }
            set
            {
               _middleName = value ;
            } 
        }

    }

}
