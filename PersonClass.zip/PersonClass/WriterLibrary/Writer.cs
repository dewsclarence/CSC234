﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WriterLibrary
{
    public static class Writer
    {
        public static string WriteToFile()
        {
            StreamWriter outputFile;
            try
            {
                outputFile = File.CreateText("UserInformation.txt");
                foreach (Person person in ListBuilder.people)
                {
                    outputFile.WriteLine($"{person.FirstName},{person.MiddleName},{person.LastName},{person.Age}");
                }
                outputFile.Close();
                return "Saved";
            }
            catch(Exception ex)
            {
                string message = ex.Message;
                return message;
            }
        }
    }
}
